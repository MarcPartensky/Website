class Client extends Connexion {
    constructor() {
        self.url = url;
    }
    /* Return the url. */
    getUrl() {
        return
    }

}