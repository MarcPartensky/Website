class Square extends Rectangle {
  constructor(x, y, s) {
    this.x = x;
    this.y = y;
    this.s = s;
  }
}
