class Node {
    constructor(children, parent) {
        this.children = children;
        this.parent = parent;
    }
    get()
}