class Triangle extends Polygon {
  constructor(p1, p2, p3, color, lineWidth, areaColor) {
    super(p1, p2, p3);
    this.lineWidth = lineWidth;
    this.color = color;
    this.areaColor = areaColor;
  }
  get area() {
    return ;
  }
}
