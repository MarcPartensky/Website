class Game extends Manager {
  // constructor(canvas, terrain, dt=1) {
  //   super(canvas, dt);
  //   this.terrain = terrain;
  //   this.deactivate();
  // }
  // update() {

  // }
  // show() {
  //   this.terrain.show(this.context);
  // }
  // deactivate() {
  //   window.addEventListener("keydown", function(e) {
  //     // prevent default actions from space and arrow keys
  //     if([32, 37, 38, 39, 40].indexOf(e.keyCode) > -1) {
  //         e.preventDefault();
  //     }
  //   }, false);
  // }
}