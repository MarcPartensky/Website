class Missile extends Entity {
    constructor(form, body, damage=0.2) {
        super(form, body)
        this.damage = damage
    }
}

