import Rectangle from './rectangle.js';

export default class Box extends Rectangle {
  constructor(...ars, position, size) {

  }
}

