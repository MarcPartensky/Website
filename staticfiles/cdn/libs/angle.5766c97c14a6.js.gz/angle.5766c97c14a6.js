var Angle = {
  toRadian: function(angle) {
    return Math.pi*angle/180;
  },
  toDegree: function(angle) {
    return 180*angle/Math.pi;
  }
}
